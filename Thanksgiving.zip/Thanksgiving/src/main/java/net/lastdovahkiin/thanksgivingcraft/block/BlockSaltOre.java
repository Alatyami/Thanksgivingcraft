package net.lastdovahkiin.thanksgivingcraft.block;

import net.minecraft.world.level.block.Block;

public class BlockSaltOre extends Block
{
    public BlockSaltOre(Properties properties)
    {
        super(properties);
    }
}
